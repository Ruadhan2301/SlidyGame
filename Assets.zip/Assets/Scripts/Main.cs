﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Main : MonoBehaviour
{
    public bool cycling = true;
    public float range = 290;
    public int sweetspotL;
    public int sweetspotR;
    public float markerX = 0f;
    public float timeX = 0f;

    public GameObject bar;
    public GameObject sweetspotMarker;
    public GameObject marker;

    private Image markerImg;
    // Start is called before the first frame update
    void Start()
    {
        RectTransform rectTrans = sweetspotMarker.GetComponent<RectTransform>();
        rectTrans.offsetMin = new Vector2(sweetspotL,rectTrans.offsetMin.y);
        rectTrans.offsetMax = new Vector2(-sweetspotR,rectTrans.offsetMax.y);

        markerImg = marker.GetComponent<Image>();
        markerImg.color = Color.red;
    }

    // Update is called once per frame
    void Update()
    {


        if (cycling)
        {
            timeX += Time.deltaTime;

            markerX = Mathf.Sin(timeX) * ((range) / 2f);
            marker.transform.localPosition = new Vector3(markerX - 5, 0, 0);

            if (markerX + (range / 2f) < range - sweetspotR && markerX + (range/2f) > sweetspotL)
            {
                markerImg.color = Color.yellow;
                if (Input.GetMouseButtonUp(0))
                {
                    cycling = false;
                }
            }
            else
            {
                markerImg.color = Color.red;
            }

        }
        else
        {
            if (Input.GetMouseButtonUp(1))
            {
                cycling = true;
            }
        }
    }
}
